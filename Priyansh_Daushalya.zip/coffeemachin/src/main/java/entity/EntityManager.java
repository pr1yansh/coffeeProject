package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * Singleton class responsible for bookkeeping of all the ingredients present in the system
 * @author pdaushal
 *
 */
public class EntityManager implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3713075619714403237L;
	
	
	/**
	 * indicates the warning level cutoff for the incredients
	 * It can be set in VM args,
	 * Default value is 40
	 */
	private static final Integer WARNING_LEVEL = Integer.parseInt(System.getProperty("warning_level", "40"));
	
	
	private static volatile EntityManager manager = null;
	
	/**
	 * ingredients map
	 */
	private volatile Map<String, Integer> incredients;
	
	
	/**
	 * private constructor
	 */
	private EntityManager() {
		incredients = new HashMap<>();
	}
	
	/**
	 * 
	 * @return returns the single instance
	 */
	public static synchronized EntityManager getInstance() {
		if (manager == null) {
			synchronized (EntityManager.class) {
				if (manager == null) {
					manager = new EntityManager();
				}
			}
		}
		return manager;
	}
	
	/**
	 * takes input of the ingredients that are required to prepare the drink by cook and returns the output
	 * 
	 * @param required required ingredients for the drink
	 * @return if the drink can be made and if so, ingredients if any below warning level
	 */
	public String computeDrink(Map<String, Integer> required) {
		String completed = "Drink is served. ";
		String error = validateDoable(required);
		if (error != null) {
			return error;
		}
		String warnings = process(required);
		if (warnings != null)
			completed += warnings;
		return completed;
	}
	
	/**
	 * 
	 * @param required required ingredients for the drink
	 * @return returns output with the list of values below warning level
	 */
	private String process(Map<String, Integer> required) {
		String ans = null;
		List<String> warns = new ArrayList<>();
		for (Map.Entry<String, Integer> entry : required.entrySet()) {
			incredients.put(entry.getKey(), incredients.get(entry.getKey()) - entry.getValue());
			if (incredients.get(entry.getKey()) <= WARNING_LEVEL) {
				warns.add(entry.getKey().toString());
			}
		}
		if (!warns.isEmpty()) {
			ans = warns.stream().collect(Collectors.joining(" ,")) + " are below warning level";
		}
		return ans;
	}
	/**
	 * 
	 * @param required required ingredients for the drink
	 * @return validates if ample ingredients are present to complete the drink
	 */
	private String validateDoable(Map<String, Integer> required) {
		String error = null;
		for (Map.Entry<String, Integer> entry : required.entrySet()) {
			if(incredients.get(entry.getKey()) == null) {
				incredients.put(entry.getKey(), 0);
			}
			if (incredients.get(entry.getKey()) < entry.getValue()) {
				return entry.getKey() + " is inadequate; cannot complete the drink";
			}
		}
		return error;
	}
	
	/**
	 * populates the ingredients map with new values
	 * @param map updated list of quantities of ingredients
	 */
	public void populateIncredients(Map<String, Integer> map) {
		incredients.putAll(map);
	}

}
