package coffeemachin;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.ResourceBundle;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import bootup.Initializer;

@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
public class TestUser {
	private Initializer coffeeMachine;
	private InputStream tStream; 
	private Properties tests;
	
	@BeforeAll
	public void setup() {
		coffeeMachine = new Initializer();
		InputStream stream = TestUser.class.getResourceAsStream("/config.json");
		ObjectMapper mapper = new ObjectMapper();
		JsonNode node = null;
		try {
			node = mapper.readTree(stream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tStream = TestUser.class.getResourceAsStream("/tests.properties");
		tests = new Properties();
		try {
			tests.load(tStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		coffeeMachine.initialize(node);
	}
	
	@Test
	@Order(1)
	public void test1() {
		String temp = tests.getProperty("test1");
		String[] cases = temp.split(";");
		for(String cas: cases) {
			List<String> input = Arrays.asList(cas.split(","));
			List<String> ans = coffeeMachine.prepareDrink(input);
			System.out.println("Order Completed:");
			ans.stream()
				.forEach(System.out::println);
		}
		ObjectMapper mapper = new ObjectMapper();
		InputStream strm = TestUser.class.getResourceAsStream("/refill.json");
		try {
			JsonNode node = mapper.readTree(strm);
			coffeeMachine.populateIncredients(node);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(String cas: cases) {
			List<String> input = Arrays.asList(cas.split(","));
			List<String> ans = coffeeMachine.prepareDrink(input);
			System.out.println("Order Completed:");
			ans.stream()
				.forEach(System.out::println);
		}
		
				
	}
	
	
}
